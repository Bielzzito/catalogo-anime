-- Script do banco de dados MySQL (execute uma vez antes de iniciar o servidor)
CREATE DATABASE IF NOT EXISTS catalogo_animes
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE catalogo_animes;

CREATE TABLE IF NOT EXISTS animes (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  titulo        VARCHAR(120)  NOT NULL,
  genero        VARCHAR(60)   NOT NULL,
  episodios     INT           NOT NULL CHECK (episodios >= 0),
  status        VARCHAR(20)   NOT NULL,
  classificacao DECIMAL(3,1)  NOT NULL CHECK (classificacao BETWEEN 0 AND 10)
);

-- Dados de exemplo (opcional)
INSERT INTO animes (titulo, genero, episodios, status, classificacao) VALUES
  ('Fullmetal Alchemist: Brotherhood', 'Aventura', 64, 'Finalizado', 9.1),
  ('Frieren', 'Fantasia', 28, 'Finalizado', 9.3),
  ('One Piece', 'Aventura', 1100, 'Em exibição', 8.7);
