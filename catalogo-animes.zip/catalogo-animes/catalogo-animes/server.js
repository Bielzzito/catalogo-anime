// Arquivo que INICIA o servidor: node server.js
const express = require('express');
const path = require('path');
const animeRoutes = require('./routes/animeRoutes');

const app = express();
const PORTA = 3000;

app.use(express.json());                                  // lê o corpo JSON das requisições
app.use(express.static(path.join(__dirname, 'public')));   // serve o front-end (HTML/CSS/JS)
app.use('/api/animes', animeRoutes);                       // todas as rotas da API

// Rota inexistente da API
app.use('/api', (req, res) => res.status(404).json({ erro: 'Rota não encontrada.' }));

// Erro inesperado (ex.: falha no banco de dados)
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ erro: 'Erro interno no servidor.' });
});

app.listen(PORTA, () => {
  console.log(`Servidor rodando em http://localhost:${PORTA}`);
});
