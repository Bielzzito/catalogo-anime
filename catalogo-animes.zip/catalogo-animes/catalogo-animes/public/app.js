// JavaScript do front-end: lê o formulário, chama a API com fetch e desenha a lista.
const API = '/api/animes';

const form = document.getElementById('form-anime');
const lista = document.getElementById('lista');
const contador = document.getElementById('contador');
const mensagem = document.getElementById('mensagem');
const busca = document.getElementById('busca');
const btnSalvar = document.getElementById('btn-salvar');
const btnCancelar = document.getElementById('btn-cancelar');
const formTitulo = document.getElementById('form-titulo');
const painel = document.querySelector('.painel');

let editandoId = null; // null = modo cadastro | número = id do anime em edição

// ---------- mensagens para o usuário ----------
function mostrarMensagem(texto, tipo) {
  mensagem.textContent = texto;
  mensagem.className = 'mensagem ' + (tipo || '');
}

// ---------- READ: busca os animes na API ----------
async function carregarAnimes() {
  try {
    const termo = busca.value.trim();
    const resposta = await fetch(`${API}?busca=${encodeURIComponent(termo)}`);
    if (!resposta.ok) throw new Error();
    const animes = await resposta.json();
    desenharLista(animes);
  } catch {
    lista.innerHTML = '';
    const aviso = document.createElement('li');
    aviso.className = 'vazio';
    aviso.textContent = 'Não foi possível carregar os animes. Verifique se o servidor está rodando.';
    lista.appendChild(aviso);
    contador.textContent = '';
  }
}

function desenharLista(animes) {
  lista.innerHTML = '';
  contador.textContent = animes.length === 1 ? '1 anime no catálogo' : `${animes.length} animes no catálogo`;

  if (animes.length === 0) {
    const vazio = document.createElement('li');
    vazio.className = 'vazio';
    vazio.textContent = busca.value.trim()
      ? 'Nenhum anime encontrado para essa busca.'
      : 'Nenhum anime cadastrado ainda. Use o formulário para adicionar o primeiro.';
    lista.appendChild(vazio);
    return;
  }

  animes.forEach(anime => lista.appendChild(criarItem(anime)));
}

function criarItem(anime) {
  const li = document.createElement('li');
  li.className = 'item';

  const selo = document.createElement('div');
  selo.className = 'selo';
  selo.textContent = Number(anime.classificacao).toFixed(1);
  selo.title = 'Classificação';

  const info = document.createElement('div');
  info.className = 'info';
  const titulo = document.createElement('h3');
  titulo.textContent = anime.titulo; // textContent evita injeção de HTML
  const detalhes = document.createElement('p');
  detalhes.className = 'detalhes';
  detalhes.textContent = `${anime.genero} • ${anime.episodios} episódios`;
  const status = document.createElement('span');
  status.className = 'status ' + (anime.status === 'Em exibição' ? 'em-exibicao' : anime.status === 'Em breve' ? 'em-breve' : '');
  status.textContent = anime.status;
  info.append(titulo, detalhes, status);

  const acoes = document.createElement('div');
  acoes.className = 'acoes';
  const btnEditar = document.createElement('button');
  btnEditar.className = 'acao';
  btnEditar.textContent = 'Editar';
  btnEditar.addEventListener('click', () => iniciarEdicao(anime));
  const btnExcluir = document.createElement('button');
  btnExcluir.className = 'acao excluir';
  btnExcluir.textContent = 'Excluir';
  btnExcluir.addEventListener('click', () => excluirAnime(anime));
  acoes.append(btnEditar, btnExcluir);

  li.append(selo, info, acoes);
  return li;
}

// ---------- CREATE e UPDATE: envio do formulário ----------
form.addEventListener('submit', async (evento) => {
  evento.preventDefault(); // impede a página de recarregar

  const dados = {
    titulo: document.getElementById('titulo').value,
    genero: document.getElementById('genero').value,
    episodios: document.getElementById('episodios').value,
    status: document.getElementById('status').value,
    classificacao: document.getElementById('classificacao').value
  };

  // Se há um id em edição usa PUT /api/animes/:id, senão POST /api/animes
  const editando = editandoId !== null;
  const url = editando ? `${API}/${editandoId}` : API;
  const metodo = editando ? 'PUT' : 'POST';

  try {
    const resposta = await fetch(url, {
      method: metodo,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dados)
    });
    const corpo = await resposta.json();

    if (!resposta.ok) {
      mostrarMensagem(corpo.erro || 'Não foi possível salvar o anime.', 'erro');
      return;
    }

    const nome = corpo.titulo;
    sairDoModoEdicao();
    mostrarMensagem(editando ? `"${nome}" foi atualizado.` : `"${nome}" foi cadastrado.`, 'sucesso');
    carregarAnimes();
  } catch {
    mostrarMensagem('Sem conexão com o servidor. Tente novamente.', 'erro');
  }
});

// ---------- UPDATE: coloca os dados do anime no formulário ----------
function iniciarEdicao(anime) {
  editandoId = anime.id;
  document.getElementById('titulo').value = anime.titulo;
  document.getElementById('genero').value = anime.genero;
  document.getElementById('episodios').value = anime.episodios;
  document.getElementById('status').value = anime.status;
  document.getElementById('classificacao').value = anime.classificacao;

  formTitulo.textContent = 'Editando anime';
  btnSalvar.textContent = 'Salvar alterações';
  btnCancelar.hidden = false;
  painel.classList.add('editando');
  mostrarMensagem('');
  document.getElementById('titulo').focus();
}

function sairDoModoEdicao() {
  editandoId = null;
  form.reset();
  formTitulo.textContent = 'Novo anime';
  btnSalvar.textContent = 'Cadastrar anime';
  btnCancelar.hidden = true;
  painel.classList.remove('editando');
  mostrarMensagem('');
}
btnCancelar.addEventListener('click', sairDoModoEdicao);

// ---------- DELETE ----------
async function excluirAnime(anime) {
  if (!confirm(`Excluir "${anime.titulo}"? Essa ação não pode ser desfeita.`)) return;

  try {
    const resposta = await fetch(`${API}/${anime.id}`, { method: 'DELETE' });
    const corpo = await resposta.json();

    if (!resposta.ok) {
      mostrarMensagem(corpo.erro || 'Não foi possível excluir o anime.', 'erro');
      return;
    }
    if (editandoId === anime.id) sairDoModoEdicao();
    mostrarMensagem(`"${anime.titulo}" foi excluído.`, 'sucesso');
    carregarAnimes();
  } catch {
    mostrarMensagem('Sem conexão com o servidor. Tente novamente.', 'erro');
  }
}

// ---------- busca ao digitar ----------
busca.addEventListener('input', carregarAnimes);

// Ao abrir a página, carrega a lista
carregarAnimes();
