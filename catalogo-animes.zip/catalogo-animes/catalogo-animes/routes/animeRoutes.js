// Rotas da API: ligam cada método HTTP + caminho a uma função do controller.
const express = require('express');
const controller = require('../controllers/animeController');

const router = express.Router();

router.get('/', controller.listar);          // READ   - lista todos
router.get('/:id', controller.buscarPorId);  // READ   - busca um
router.post('/', controller.criar);          // CREATE - cadastra
router.put('/:id', controller.atualizar);    // UPDATE - edita
router.delete('/:id', controller.excluir);   // DELETE - remove

module.exports = router;
