// Controller: contém a lógica de cada operação do CRUD.
// Recebe a requisição (req), fala com o banco (db) e devolve a resposta (res).
const db = require('../config/database');

const STATUS_VALIDOS = ['Em exibição', 'Finalizado', 'Em breve'];

// Valida os dados recebidos; devolve uma mensagem de erro ou null se estiver tudo certo
function validar(dados) {
  const { titulo, genero, episodios, status, classificacao } = dados;

  if (!titulo || !String(titulo).trim()) return 'O título é obrigatório.';
  if (!genero || !String(genero).trim()) return 'O gênero é obrigatório.';

  const eps = Number(episodios);
  if (episodios === '' || episodios == null || !Number.isInteger(eps) || eps < 0)
    return 'Episódios deve ser um número inteiro maior ou igual a 0.';

  if (!STATUS_VALIDOS.includes(status))
    return 'Status inválido. Use: ' + STATUS_VALIDOS.join(', ') + '.';

  const nota = Number(classificacao);
  if (classificacao === '' || classificacao == null || Number.isNaN(nota) || nota < 0 || nota > 10)
    return 'A classificação deve ser um número entre 0 e 10.';

  return null;
}

// READ (todos) - GET /api/animes  (aceita ?busca=texto)
async function listar(req, res, next) {
  try {
    const busca = (req.query.busca || '').trim();
    const [animes] = busca
      ? await db.query('SELECT * FROM animes WHERE titulo LIKE ? OR genero LIKE ? ORDER BY titulo',
          [`%${busca}%`, `%${busca}%`])
      : await db.query('SELECT * FROM animes ORDER BY titulo');
    res.json(animes);
  } catch (erro) { next(erro); }
}

// READ (um) - GET /api/animes/:id
async function buscarPorId(req, res, next) {
  try {
    const [linhas] = await db.query('SELECT * FROM animes WHERE id = ?', [req.params.id]);
    if (linhas.length === 0) return res.status(404).json({ erro: 'Anime não encontrado.' });
    res.json(linhas[0]);
  } catch (erro) { next(erro); }
}

// CREATE - POST /api/animes
async function criar(req, res, next) {
  try {
    const erro = validar(req.body);
    if (erro) return res.status(400).json({ erro });

    const { titulo, genero, episodios, status, classificacao } = req.body;
    const [resultado] = await db.query(
      'INSERT INTO animes (titulo, genero, episodios, status, classificacao) VALUES (?, ?, ?, ?, ?)',
      [titulo.trim(), genero.trim(), Number(episodios), status, Number(classificacao)]
    );

    const [linhas] = await db.query('SELECT * FROM animes WHERE id = ?', [resultado.insertId]);
    res.status(201).json(linhas[0]);
  } catch (erro) { next(erro); }
}

// UPDATE - PUT /api/animes/:id
async function atualizar(req, res, next) {
  try {
    const erro = validar(req.body);
    if (erro) return res.status(400).json({ erro });

    const [existe] = await db.query('SELECT id FROM animes WHERE id = ?', [req.params.id]);
    if (existe.length === 0) return res.status(404).json({ erro: 'Anime não encontrado.' });

    const { titulo, genero, episodios, status, classificacao } = req.body;
    await db.query(
      `UPDATE animes
       SET titulo = ?, genero = ?, episodios = ?, status = ?, classificacao = ?
       WHERE id = ?`,
      [titulo.trim(), genero.trim(), Number(episodios), status, Number(classificacao), req.params.id]
    );

    const [linhas] = await db.query('SELECT * FROM animes WHERE id = ?', [req.params.id]);
    res.json(linhas[0]);
  } catch (erro) { next(erro); }
}

// DELETE - DELETE /api/animes/:id
async function excluir(req, res, next) {
  try {
    const [resultado] = await db.query('DELETE FROM animes WHERE id = ?', [req.params.id]);
    if (resultado.affectedRows === 0) return res.status(404).json({ erro: 'Anime não encontrado.' });
    res.json({ mensagem: 'Anime excluído com sucesso.' });
  } catch (erro) { next(erro); }
}

module.exports = { listar, buscarPorId, criar, atualizar, excluir };
