// Configuração da conexão com o banco de dados MySQL.
// Ajuste user e password para os dados do SEU MySQL (ou use variáveis de ambiente).
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'admin',
  database: process.env.DB_NAME || 'catalogo_animes',
  waitForConnections: true,
  connectionLimit: 10
});

module.exports = pool;
