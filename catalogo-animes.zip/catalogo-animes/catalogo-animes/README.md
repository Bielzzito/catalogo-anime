# Catálogo de Animes – CRUD completo

Sistema web para gerenciar animes (título, gênero, episódios, status e classificação).
Stack: HTML/CSS/JavaScript (fetch) + Node.js + Express + MySQL.

## Como rodar
1. Instale o Node.js (versão 18 ou superior).
2. Instale e inicie o MySQL (versão 8.0.16 ou superior).
3. Crie o banco e a tabela executando o script `banco.sql`:
   - Pelo terminal: `mysql -u root -p < banco.sql`
   - Ou abra o `banco.sql` no MySQL Workbench e execute tudo.
4. Em `config/database.js`, confira `user` e `password` do seu MySQL (ou defina as variáveis `DB_USER` e `DB_PASSWORD`).
5. Na pasta do projeto: `npm install`
6. Inicie: `npm start`
7. Abra http://localhost:3000

## Estrutura
| Arquivo | Função |
|---|---|
| `server.js` | Inicia o servidor, liga o front-end estático e as rotas da API |
| `routes/animeRoutes.js` | Define as rotas e o método HTTP de cada uma |
| `controllers/animeController.js` | Lógica do CRUD, validação e SQL |
| `config/database.js` | Conexão (pool) com o banco MySQL |
| `banco.sql` | Script que cria o banco `catalogo_animes`, a tabela `animes` e dados de exemplo |
| `public/index.html` | Estrutura da interface |
| `public/style.css` | Visual da interface |
| `public/app.js` | JavaScript do front-end: fetch, desenho da lista, formulário |

## Banco de dados – `catalogo_animes`, tabela `animes`
| Campo | Tipo | Descrição |
|---|---|---|
| id | INT (PK, AUTO_INCREMENT) | Identifica cada anime |
| titulo | VARCHAR(120) | Nome do anime |
| genero | VARCHAR(60) | Gênero principal |
| episodios | INT | Quantidade de episódios (≥ 0) |
| status | VARCHAR(20) | Em exibição, Finalizado ou Em breve |
| classificacao | DECIMAL(3,1) | Nota de 0 a 10 |

## Rotas da API
| Operação | Método | Rota | Corpo |
|---|---|---|---|
| Create | POST | `/api/animes` | JSON com os campos |
| Read (todos) | GET | `/api/animes` (`?busca=texto`) | – |
| Read (um) | GET | `/api/animes/:id` | – |
| Update | PUT | `/api/animes/:id` | JSON com os campos |
| Delete | DELETE | `/api/animes/:id` | – |

Códigos usados: 200 (ok), 201 (criado), 400 (dados inválidos), 404 (não encontrado), 500 (erro no servidor).

## Fluxo de dados (exemplo: cadastrar)
1. O usuário preenche o formulário e clica em "Cadastrar anime".
2. `app.js` captura o `submit`, monta um objeto e chama `fetch('/api/animes', { method: 'POST', ... })`.
3. O Express (`server.js`) recebe, o `express.json()` converte o corpo e a rota em `animeRoutes.js` chama `criar`.
4. `criar` (controller) valida os dados e executa o `INSERT` no MySQL.
5. O banco grava e o controller responde com o registro criado (status 201).
6. O `fetch` recebe a resposta, o front-end mostra a mensagem e chama `carregarAnimes()` para atualizar a lista.

## Como o sistema sabe qual registro alterar ou excluir?
Cada anime tem um `id`. O botão Editar/Excluir leva o `id` na URL (`/api/animes/5`), o Express lê em `req.params.id` e o SQL usa `WHERE id = ?`.

## E se o banco não estivesse conectado?
Com o MySQL parado ou com dados de conexão errados, as consultas falham (ex.: `ECONNREFUSED`). O controller captura o erro no `catch` e o middleware do `server.js` responde 500; o front-end exibe uma mensagem ao usuário e a lista não carrega.

## Para mostrar na apresentação
- Abra o MySQL Workbench (ou rode `SELECT * FROM animes;` no terminal) e mostre o registro aparecendo após o Create, mudando após o Update e sumindo após o Delete.
- Mostre o DevTools (aba Network) para ver as requisições POST, GET, PUT e DELETE acontecendo.
